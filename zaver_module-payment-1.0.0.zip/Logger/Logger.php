<?php
namespace Zaver\Payment\Logger;

class Logger extends \Monolog\Logger
{
}